# TPTracker
Emotracker Pack for Twilight Princess

This is a basic item tracker for The Legend of Zelda: Twilight Princess SD and HD versions. 
